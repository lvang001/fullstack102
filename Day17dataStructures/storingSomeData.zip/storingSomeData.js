const group = ['Rutti', 'Emily' , 'Joseph', 'Natalee', 'Lucky']

const food = ['banana', 'apple', 'kiwi', 'blueberry', 'orange', 'pineapple', 'noodle', 'cheese' , 'chicken' , 'ribeye']

const state = [['North Carolina' , 'Raleigh', 'Cardinal'], ['South Carolina' , 'Columbia' , 'Carolina wren'] , ['Georgia' , 'Atlanta', 'Northern bobwhite'], ['Tennessee' , 'Nashville' , 'Northern mockingbird'] , ['Texas' , 'Austin' , 'Northern mockingbird'] , ['Virginia' , 'Richmond' , 'Cardinal'] , ['Washington' , 'Olympia' , 'American Goldfinch']]


console.log(group);
console.log(food);
console.log(state);