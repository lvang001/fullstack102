for(let i=0; i < 21; i++) {
    switch (i) {
        case 5: 
        console.log(i+ ' divisible by 5');
        break;
        case 10:
        console.log(i + ' divisible by 5');
        break;
        case 15:
        console.log(i + ' divisible by 5');
        break;
        case 20:
        console.log(i + ' divisible by 5');
        break;
        default:
        console.log(i + ' not divisible by 5')
    }
}
